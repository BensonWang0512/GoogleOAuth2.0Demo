var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add Google authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = "Cookies";
    options.DefaultChallengeScheme = "Google";
})
.AddCookie(options =>
{
    options.Cookie.SecurePolicy = Microsoft.AspNetCore.Http.CookieSecurePolicy.Always; // Prevent being intercepted
    options.Cookie.HttpOnly = true; // HttpOnly prevent XSS which means cannot access it through Javascript
    options.ExpireTimeSpan = TimeSpan.FromHours(1); // Avoid setting a validity period that is too long. A validity period of 1 hour is set here.
})
.AddGoogle(googleOptions =>
{
    //Todo: this is not a good practice to just use ClientID and Client Secret like this
    googleOptions.ClientId = " ";
    googleOptions.ClientSecret = " ";
    googleOptions.Scope.Add("https://mail.google.com/"); // Todo: Important for asking user to authroize the api scope
    googleOptions.AccessType = "offline"; // Important for refresh tokens
    googleOptions.CallbackPath = "/signin-google"; // Have to have the same URI as developer set in google cloud
    googleOptions.SaveTokens = true;  // Ensure this is set to true for getting tokens

    // Manually add the prompt to force consent and thus ensure refresh token delivery (Noted: Without user consent, no matter how many times you request for refresh token later, only one will be issued during the initial authorization process)
    googleOptions.Events.OnRedirectToAuthorizationEndpoint = context =>
    {
        context.Response.Redirect(context.RedirectUri + "&prompt=consent");
        return Task.CompletedTask;
    };
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
