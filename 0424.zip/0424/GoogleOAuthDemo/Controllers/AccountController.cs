﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace GoogleOAuthDemo.Controllers
{
    public class AccountController : Controller
    {
        /*  
         *  Purpose: When user click button in the main page, send a challenge using Microsoft.AspNetCore.Authentication and allow user to do scope authorization
         *  
         *  Redirect to SecureArea page if everything is valid
         */
        public IActionResult Login(string returnUrl = "/Account/SecureArea")
        {
            return Challenge(new AuthenticationProperties { RedirectUri = returnUrl }, "Google");
        }


        /*
         *  Purpose: Logout User, remove the cookie
         *  
         *  In program.cs, I make sure users choose an account for extra protection.
         *  
         *  Potential issue: I'm using [Authorize] to guard some pages, but sometimes it might not work right when users are already logged in on Chrome.
         */
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

        /*
         *  Purpose: show SecureArea page and using [Authorize] to guard it.
         */
        [Authorize]
        public IActionResult SecureArea()
        {
            return View(); 
        }

        /*  
         *  Purpose: First time user can create a refresh token text file with this method
         *  
         *  Refresh token might stop working for one of the following reasons:
         *   1.The user has revoked your app's access 
         *   2.Refresh token has not been used for six months
         *   3.User changed passwords
         *   4.User account has exceeded a maximum number(100) of granted refresh tokens
         *   
         *  Worth to mention that when publishing status is testing, refresh token expired in 7 days
         *  
         *  Potential issue: I use my local absolute path to create text file.
         */
        [Authorize]
        public async Task<IActionResult> GetRefreshToken()
        {
            // Request the access_token and save the value into text file
            var refreshToken = await HttpContext.GetTokenAsync("refresh_token");
            if (string.IsNullOrEmpty(refreshToken))
            {
                Console.WriteLine("Refresh Token is null or empty.");
            }
            else
            {
                Console.WriteLine($"Refresh Token: {refreshToken}");

                // Todo: Set an absolute path for saving a file.
                string folderPath = @"C:\Users\Benson\Desktop\tokens";
                string fileName = "RefreshToken.txt";
                string fullPath = Path.Combine(folderPath, fileName);

                // if there isn't a folder with the same name at that path then create one.
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Write the accessToken into Text file
                await System.IO.File.WriteAllTextAsync(fullPath, refreshToken);
            }

            // Redirect to the SecureArea action
            return RedirectToAction("SecureArea");
        }

        /*  
         *  Purpose: Generate a fresh access key by selecting a text file containing a refresh key from local storage.
         *  
         *  Potential issue: I use my local absolute path to create text file.
         */
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> RefreshAccessToken(IFormFile tokenFile)
        {
            if (tokenFile == null || tokenFile.Length == 0)
            {
                Console.WriteLine("No file was uploaded.");
                return RedirectToAction("Error"); // Redirect to an error page or handle appropriately
            }

            string refreshToken;
            using (var stream = new StreamReader(tokenFile.OpenReadStream()))
            {
                refreshToken = await stream.ReadToEndAsync();
            }

            if (string.IsNullOrEmpty(refreshToken))
            {
                Console.WriteLine("Refresh Token is null or empty.");
                return RedirectToAction("Error"); // Redirect to an error page or handle appropriately
            }

            Console.WriteLine($"Access Token: {refreshToken}");

            // Use the refresh token to obtain a new access token
            var newAccessToken = await GetNewAccessToken(refreshToken);
            if (string.IsNullOrEmpty(newAccessToken))
            {
                Console.WriteLine("Failed to obtain new access token.");
                return RedirectToAction("Error"); // Handle appropriately
            }

            Console.WriteLine($"New Access Token: {newAccessToken}");

            // Save the new access token to a file
            string folderPath = @"C:\Users\Benson\Desktop\tokens";
            string fileName = "AccessToken.txt";
            string fullPath = Path.Combine(folderPath, fileName);

            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            await System.IO.File.WriteAllTextAsync(fullPath, newAccessToken);

            return RedirectToAction("SecureArea");
        }

        /*  Purpose: Helper method for RefreshAccessToken, use the refreshToken and other necessary informations to request a new access token from Google
         *  
         *  If valid, create a textfile contain a fresh access token
         *  Potential issue: I hardcode the client id and client secret here which is not a good practice for safety issue.
         */
        private async Task<string> GetNewAccessToken(string refreshToken)
        {
            using (var client = new HttpClient())
            {
                // Prepare the request data
                var postData = new Dictionary<string, string>
                {
                    {"client_id", " "},  // Replace with your actual client ID
                    {"client_secret", " "},  // Replace with your actual client secret
                    {"refresh_token", refreshToken},
                    {"grant_type", "refresh_token"}
                };

                var content = new FormUrlEncodedContent(postData);

                try
                {
                    // Send a POST request to the Google OAuth2 token endpoint
                    var response = await client.PostAsync("https://oauth2.googleapis.com/token", content);

                    if (response.IsSuccessStatusCode)
                    {
                        // Parse the JSON response and return the access token
                        var responseString = await response.Content.ReadAsStringAsync();
                        var responseData = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(responseString);
                        return responseData.access_token;
                    }
                    else
                    {
                        // Log error response if the request was not successful
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        Console.WriteLine($"Error fetching new access token: {errorResponse}");
                    }
                }
                catch (Exception ex)
                {
                    // Log exceptions to the console or a file
                    Console.WriteLine($"Exception occurred while fetching new access token: {ex.Message}");
                }

                return null;  // Return null if the token was not refreshed successfully
            }
        }

        /*  
         *  Purpose: First time user can create a access token text file with this method
         *  
         *  Access token should expire in 1 hours
         *  
         *  Potential issue: I use my local absolute path to create text file.
         */
        [Authorize]
        public async Task<IActionResult> GetAccessToken()
        {
            // Request the access_token and save the value into text file
            var accessToken = await HttpContext.GetTokenAsync("access_token");
            if (string.IsNullOrEmpty(accessToken))
            {
                Console.WriteLine("Access Token is null or empty.");
            }
            else
            {
                Console.WriteLine($"Access Token: {accessToken}");

                // Todo: Set an absolute path for saving a file.
                string folderPath = @"C:\Users\Benson\Desktop\tokens";
                string fileName = "AccessToken.txt";
                string fullPath = Path.Combine(folderPath, fileName);

                // if there isn't a folder with the same name at that path then create one.
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Write the accessToken into Text file
                await System.IO.File.WriteAllTextAsync(fullPath, accessToken);
            }

            // Redirect to the SecureArea action
            return RedirectToAction("SecureArea");
        }

        /*  
         *  Purpose: Access and show first email content
         *  
         *  Use tempData to communicate data between Controller and view
         *  Customize GmailServiceWrapper.cs as a tool to use google api
         *  
         *  Potential issue: 1. Know how to use tempData, might lose data if not using it becuase redirect
         *                   2. GmailServiceWrapper.cs is written very specific for getting first email content only and sometimes email content will be empty due to your first email is not text/plain or similar
         */
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> GetFirstEmailContent(IFormFile tokenFile)
        {
            if (tokenFile == null || tokenFile.Length == 0)
            {
                Console.WriteLine("No file was uploaded.");
                return RedirectToAction("Error"); // Redirect to an error page or handle appropriately
            }

            string accessToken;
            using (var stream = new StreamReader(tokenFile.OpenReadStream()))
            {
                accessToken = await stream.ReadToEndAsync();
            }

            if (string.IsNullOrEmpty(accessToken))
            {
                Console.WriteLine("Access Token is null or empty.");
                return RedirectToAction("Error"); // Redirect to an error page or handle appropriately
            }

            Console.WriteLine($"Access Token: {accessToken}");

            var gmailService = new GmailServiceWrapper(accessToken);
            var emailContent = await gmailService.GetFirstEmailContent();
            
            TempData["EmailContent"] = emailContent;
            Console.WriteLine(emailContent);

            return RedirectToAction("SecureArea");
        }

        /*
         *  Purpose: Use case 4 but auto check with one button
         *  
         *  1.Check the presence of AccessToken.txt in the specified directory.
         *  2.If AccessToken.txt exists, read the access token and use it to fetch the first email content.
         *  3.If AccessToken.txt does not exist, check for RefreshToken.txt.
         *  4.If RefreshToken.txt exists, use the refresh token to request a new access token, save the new token, and then fetch the first email content.
         *  5.If neither token file exists, redirect to an error page.
         *  
         *  Potential issue: there could be case where at the folderPath, if only valid access token exist, still able to use API, but no refresh token
         */
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> GetFirstEmailContentAuto()
        {
            string folderPath = @"C:\Users\Benson\Desktop\tokens";
            string accessTokenFilePath = Path.Combine(folderPath, "AccessToken.txt");
            string refreshTokenFilePath = Path.Combine(folderPath, "RefreshToken.txt");

            string accessToken = null;
            string refreshToken = null;


            if (System.IO.File.Exists(accessTokenFilePath))
            {
                accessToken = await System.IO.File.ReadAllTextAsync(accessTokenFilePath);
            }

            
            if (!string.IsNullOrEmpty(accessToken))
            {
                // Can find an access token and show first email content
                var gmailService = new GmailServiceWrapper(accessToken);
                var emailContent = await gmailService.GetFirstEmailContent();
                TempData["EmailContent"] = emailContent;
                return RedirectToAction("SecureArea");
            }
            else
            {
                // Cannot find an access token
                if (System.IO.File.Exists(refreshTokenFilePath))
                {
                    refreshToken = await System.IO.File.ReadAllTextAsync(refreshTokenFilePath);
                }

                if (!string.IsNullOrEmpty(refreshToken))
                {
                    // Cannot find an access token - can find a refresh token
                    accessToken = await GetNewAccessToken(refreshToken);
                    if (!string.IsNullOrEmpty(accessToken))
                    {
                        // Cannot find an access token - can find a refresh token - can create a fresh access token and show first email content
                        await System.IO.File.WriteAllTextAsync(accessTokenFilePath, accessToken);

                        var gmailService = new GmailServiceWrapper(accessToken);
                        var emailContent = await gmailService.GetFirstEmailContent();
                        TempData["EmailContent"] = emailContent;
                        return RedirectToAction("SecureArea");
                    }
                    else
                    {
                        // Cannot find an access token - can find a refresh token - cannot create a fresh access token
                        Console.WriteLine("Fail to create a fresh access token by your refresh token");
                        return RedirectToAction("Error"); 
                    }
                }
            }

            // Cannot find an access token and a refresh token
            Console.WriteLine("No Tokens at all!");
            return RedirectToAction("Error");
        }                   

        /*
         *  Purpose: error page shown when error happens
         */
        public IActionResult Error()
        {
            return View();
        }
    }
}
