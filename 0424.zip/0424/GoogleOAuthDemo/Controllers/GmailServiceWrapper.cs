﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Gmail.v1;
using Google.Apis.Services;

namespace GoogleOAuthDemo
{
    public class GmailServiceWrapper
    {
        private readonly string _accessToken;

        /*
         *  Purpose: create constructor that use access token to get first email content
         */
        public GmailServiceWrapper(string accessToken)
        {
            _accessToken = accessToken;
        }

        /*
         *  Purpose: This method follows the standard flow for retrieving Gmail content. 
         *  It verifies the access token, encapsulates it within a service object, 
         *  and then utilizes this object to fetch the first email in a list.
         */
        public async Task<string> GetFirstEmailContent()
        {
            try
            {
                var credential = GoogleCredential.FromAccessToken(_accessToken);
                var service = new GmailService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential
                });

                // Get the list of messages
                var listRequest = service.Users.Messages.List("me");
                listRequest.MaxResults = 1; // Only retrieve one message
                var messages = await listRequest.ExecuteAsync();

                if (messages.Messages != null && messages.Messages.Count > 0)
                {
                    // Get the first message
                    var messageId = messages.Messages[0].Id;

                    // Get the full message details
                    var messageRequest = service.Users.Messages.Get("me", messageId);
                    var message = await messageRequest.ExecuteAsync();

                    // Extract email content
                    string emailContent = GetMessageContent(message);

                    return emailContent;
                }
                else
                {
                    return "No emails found.";
                }
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        /*
         *  Purpose: To retrieving email content and check if the content is null or empty
         */
        private string GetMessageContent(Google.Apis.Gmail.v1.Data.Message message)
        {
            if (message.Payload.Parts == null || message.Payload.Parts.Count == 0)
            {
                if (message.Payload.Body != null && !string.IsNullOrEmpty(message.Payload.Body.Data))
                {
                    return DecodeBase64String(message.Payload.Body.Data);
                }
                return "Email content not found.";
            }

            return ParseMimeParts(message.Payload.Parts);
        }

        /*
         *  Purpose: To parses the MIME parts of an email message to extract the content.
         *  
         *  Potential issue: Sometimes program will crash when type of email content cannot read
         */
        private string ParseMimeParts(IList<Google.Apis.Gmail.v1.Data.MessagePart> parts)
        {
            foreach (var part in parts)
            {
                if (part.MimeType == "text/plain" && part.Body.Data != null)
                {
                    return DecodeBase64String(part.Body.Data);
                }
                else if (part.Parts != null && part.Parts.Count > 0)
                {
                    // Recursive call to handle nested parts
                    var result = ParseMimeParts(part.Parts);
                    if (!string.IsNullOrEmpty(result))
                    {
                        return result;
                    }
                }
            }

            return "Email content not found.";
        }

        /*
         *  Purpose: To decodes a base64 encoded string and returns the decoded UTF-8 string.
         */
        private string DecodeBase64String(string base64String)
        {
            // Replace characters not allowed in base64 strings and ensure correct padding
            string base64Fixed = base64String.Replace('-', '+').Replace('_', '/');
            switch (base64Fixed.Length % 4)
            {
                // Add padding characters based on the length of the string
                case 2: base64Fixed += "=="; break;
                case 3: base64Fixed += "="; break;
            }
            // Decode the base64 string into bytes
            byte[] data = Convert.FromBase64String(base64Fixed);

            // Convert the byte array to a UTF-8 encoded string
            return System.Text.Encoding.UTF8.GetString(data);
        }
    }
}